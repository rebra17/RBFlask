def otg():
    dic = {
    "org" : "Odense Tekniske Gymnasium",
    "title" : "Scholarship",
    "txt" : "Scholarship for participation and my engagement at Young Scientists.",
    "mmyy" : "06/16"
    }
    return dic

def tic():
    dic = {
    "org" : "Young Scientists",
    "title" : "Topsoe Innovation Challenge",
    "txt" : "Award for most innovative idea within the field of chemistry and biology.",
    "mmyy" : "08/15"
    }
    return dic

def dtu():
    dic = {
    "org" : "Young Scientists",
    "title" : "DTU Challenge - Engineer the future",
    "txt" : "Won for the most innovative idea with the largest potential.",
    "mmyy" : "08/15"
    }
    return dic