def partyP():
    dic = {
    "org" : "SIF, Fraktalet",
    "title" : "Party planner",
    "txt" : "A member in Fraktalet, Party committee for engineers. Arranging arrangements for +700 people, finding location, order equipment and other, make PR etc.",
    "mmyy" : "09/17 - 01/23"
    }
    return dic

def tc():
    dic = {
    "org" : "SDU-Vikings",
    "title" : "Team Captain",
    "txt" : "Keeping track on deadlines, distributing work and ensuring the project is moving forward. Help designing and building electronics system of the car, mostly power electronics.",
    "mmyy" : "02/20 - 12/22"
    }
    return dic

def peTS():
    dic = {
    "org" : "Team Swinburne",
    "title" : "Power Electronics Engineer",
    "txt" : "Designed and build the charger for the car and helped with production, testing and troubleshooting, both mechanical and electrical.",
    "mmyy" : "09/19 - 12/19"
    }
    return dic

def peVI():
    dic = {
    "org" : "SDU-Vikings",
    "title" : "Power Electronics Engineer",
    "txt" : "Made the Charger for the car and helped with tasks, such as cable management, battery assembly, PCB soldering etc. Both mechanical and Electrical, design and/or production, implementation, test and troubleshooting.",
    "mmyy" : "01/19 - 09/19"
    }
    return dic

def cSIF():
    dic = {
    "org" : "SIF",
    "title" : "Carlsberg contact",
    "txt" : "Fraktalet, party committee for engineers.",
    "mmyy" : "01/18 - 09/19"
    }
    return dic

def tcSIF():
    dic = {
    "org" : "SIF",
    "title" : "Team Coordinator",
    "txt" : "Arranging the the volunteers teams for Tinderbox, that SIF provided.",
    "mmyy" : "01/18 - 09/19"
    }
    return dic

def vpSIF():
    dic = {
    "org" : "SIF, Fraktalet",
    "title" : "Vice-president",
    "txt" : "Making sure that planning for events were coordinated and executed in time. Working within and with SIF in order to coordinate events and budgets, that Fraktalet had to keep.",
    "mmyy" : "09/18 - 02/19"
    }
    return dic