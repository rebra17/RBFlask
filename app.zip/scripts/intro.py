

def intro():
    dic = {
    "status" : ["Graduate Electronics Engineer at Mercedes AMG High Performance Powertrain"],
    "skills" : ["MATLAB", "KiCad", "Altium", "C", "HDL", "Inventor",
              "PLECS", "PSPICE", "Excel", "HTML", "Python"],
    "skilldesc" : ["Mostly scripts for large calculations. Simulink simulating control of electronics.",
                   "Circuit design and board layout during my time in SDU-Vikings.",
                   "Circuit design nad board layout as student and research assistand in CIE.",
                   "",
                   "",
                   ""],
    "interests" : ["Formula 1", "Electric Vehicles", "Sports",
                 "Football", "Space Exploration"],
    "activities" : ["Football", "Running", "Music", "Hiking"],
    "location" : ""
    }
    return dic

def summary():
    dic = ["I am an electrical engineer, with a particular interest in power electronics. ",
                "I am passionately pursuing a career to be at the forefront of inventing new technologies for a renewable future.",
                "I am constantly seeking for opportunities to broaden my knowledge by learning and sharing experiences.", 
                "I love to work together with people who share my passion for always doing their best to create the newest, ",
                "highperformance solutions, which is why I have chosen to spend the majority of my spare time working",
                "on the Formula Student project."]
    return dic
