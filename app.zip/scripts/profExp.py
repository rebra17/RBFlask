def hpp():
    dic = {
    "company" : "Mercedes AMG High Performance Powertrain",
    "jobtitle" : "Electronics Engineering Graduate",
    "txt" : "Working on AMG One project first 6 months.",
    "mmyy" : "09/23 - Present"
    }
    return dic

def newtec():
    dic = {
    "company" : "NEWTEC Engineering",
    "jobtitle" : "Electronics Engineer",
    "txt" : "Hardware design, layout and testing for the development of new technology.",
    "mmyy" : "03/22 - 08/22"
    }
    return dic


def cie():
    dic = {
    "company" : "Center for Industrial Electronics",
    "jobtitle" : "Student Worker",
    "txt" : "Assisting with Hardware design, PCB-layout and ordering components, using Altium Designer on the HiCOMMID project.",
    "mmyy" : "04/22 - 01/23"
    }
    return dic

def siemens():
    dic = {
    "company" : "Siemens Gamesa Renewable Energy",
    "jobtitle" : "Intern",
    "txt" : "Electrical Engineer in R&D - department. Analyzing data from tests, using tools, such as MATLAB, and writing reports to customers. Design overview documents in order to distribute knowledge to other departments.",
    "mmyy" : "02/20 - 07/20"
    }
    return dic

def bilka():
    dic = {
    "company" : "Bilka Odense Bistro",
    "jobtitle" : "Part-time Employee",
    "txt" : "I began as a youth worker washing dishes, and when I turned 18 in 2015, I was offered a job as a part-time employee serving food. Not long after I became the closing manager of the bistro on my shifts.",
    "mmyy" : "10/13 - 10/17"
    }
    return dic

def flugger():
    dic = {
    "company" : "Flugger Farver, Odense",
    "jobtitle" : "Delivery man/Handyman",
    "txt" : "I was delivering paint for Fl¨ugger Farver, Blangstedg˚ardsvej in Odense to business clients all over Funen. I also helped take care of daily restocking and maintenance.",
    "mmyy" : "08/16 - 08/17"
    }
    return dic
