

def project():
    dic = {
    "url" : ["../staticFiles/Images/projects/mscthesisNobg.png", "../staticFiles/Images/projects/bscthesis.jpg",
                   "../staticFiles/Images/projects/TS_LV_DCDC.png"], 
    "head" : ["Master thesis", "Bachelor thesis",
                    "Isolated HV to LV DCDC converter"],
    "desc" : ["Space Grade bidirectional DCDC converter", "Motor inverter test setup",
                    "Isolated DCDC converter with costum designed planar magnetic components"],
    "link" : [ 'mscthesis', 'bscthesis', 'tslvdcdc']
    }
    return dic