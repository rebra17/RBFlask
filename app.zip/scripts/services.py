

def services():
    dic = {
    "url" : ["../staticFiles/Images/Icons/memory_white_24dp.svg", "../staticFiles/Images/Icons/terminal_white_24dp.svg",
                   "../staticFiles/Images/Icons/groups_white_24dp.svg"], 
    "head" : ["HW Design", "SW Design",
                    "Management"],
    "desc" : ["First service description", "Second service description",
                    "Third service description"],
    "link" : [ 'hwdesign', 'swdesign', 'management']
    }
    return dic